# PawTimer — Full Deployment Guide
### From zero to Android PWA with shared dog data

---

## What you're building

| Feature | How it works |
|---|---|
| Shared dog data | Each dog gets a unique ID like `LUNA-4829`. Both partners enter the same ID to log to the same dog. |
| No accounts | Supabase stores data per dog ID. No login needed. |
| Android full-screen | PWA manifest with `"display": "standalone"` removes browser UI. |
| Offline fallback | Service worker caches the app shell so it loads without internet. |

---

## Files you need in your repo

```
pawtimer/
├── index.html             ← Updated with PWA meta tags
├── manifest.json          ← PWA manifest
├── package.json           ← Updated with Supabase + vite-plugin-pwa
├── vite.config.js         ← Updated with PWA plugin
├── .env.example           ← Template for your secrets
├── supabase_setup.sql     ← Run once in Supabase
├── icons/
│   ├── icon-192.png       ← Home screen icon
│   ├── icon-512.png       ← Splash screen icon
│   └── icon-maskable.png  ← Android adaptive icon
└── src/
    ├── main.jsx           ← React entry point (unchanged)
    └── App.jsx            ← Main app (the new version)
```

---

## Step 1 — Set up Supabase (free, takes 5 min)

1. Go to **https://supabase.com** → Sign up / Log in
2. Click **New project** → give it a name like `pawtimer` → pick a region near you → set a database password → Create
3. Wait ~1 min for it to spin up
4. Go to **SQL Editor** (left sidebar) → **New query**
5. Open `supabase_setup.sql` and paste the entire contents → click **Run**
6. You should see: `Success. No rows returned`
7. Go to **Project Settings → API**
8. Copy:
   - **Project URL** (looks like `https://xxxxx.supabase.co`)
   - **anon / public** key (long string starting with `eyJ...`)
9. Keep these — you'll need them in Step 3

---

## Step 2 — Upload all files to GitHub

1. Go to **https://github.com/deBrikassar/Pawtimer-**
2. Upload/replace these files:

   **Files that go in the ROOT of the repo:**
   - `index.html`
   - `manifest.json`
   - `package.json`
   - `vite.config.js`
   - `.env.example`
   - `supabase_setup.sql`

   **The `src/` folder:**
   - Click **Add file → Create new file**
   - Type `src/App.jsx` in the name box — GitHub will create the folder automatically
   - Paste the contents of `App.jsx`
   - Do the same for `src/main.jsx`

   **The `icons/` folder:**
   - Click **Add file → Upload files**
   - Upload all three PNG files from the `icons/` folder
   - In the commit message box, type the path `icons/` before the filenames — OR create a file called `icons/icon-192.png` first (GitHub creates the folder)

   > **Tip:** The easiest way to upload the icons is to drag all three PNG files into the GitHub file uploader at once, then type `icons/` as a prefix if prompted.

3. Commit each change

---

## Step 3 — Add Supabase secrets to Vercel

1. Go to **https://vercel.com** → Your `Pawtimer` project → **Settings → Environment Variables**
2. Add two variables:

   | Name | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | `https://xxxxx.supabase.co` (from Step 1) |
   | `VITE_SUPABASE_ANON_KEY` | `eyJ...` (from Step 1) |

3. Click **Save** for each one
4. Go to **Deployments** → click the three dots on your latest deployment → **Redeploy**

> ⚠️ Never put real keys in `.env.example` or commit a `.env` file. Vercel reads them from its dashboard securely.

---

## Step 4 — Test the PWA on Android

1. On your Android phone, open **Chrome** and go to your Vercel URL
2. Wait for the page to fully load
3. Tap the **three-dot menu (⋮)** in Chrome
4. Tap **"Add to Home screen"** (or "Install app" if Chrome shows a banner)
5. Confirm — the app icon will appear on your home screen
6. Tap it — the app opens **full-screen with no browser UI** 🎉

---

## Step 5 — Share with your boyfriend

1. Open the app and create a new dog profile
2. After onboarding, you'll see a screen showing the **dog's unique ID** (e.g. `LUNA-4829`)
3. **Copy it** and send it to your boyfriend
4. He opens the app → taps **"Join existing dog"** → types in the ID
5. You're both now logging to the same dog — all data syncs through Supabase in real time

The dog ID is also always visible in the **Tips tab** so you can find it any time.

---

## Does it work without Supabase?

Yes. If you don't add the Supabase environment variables, the app automatically falls back to **localStorage** (device-only storage). This means:
- ✅ Everything still works on one device
- ❌ Data is not shared between you and your boyfriend
- ❌ Data is lost if you clear your browser

For shared access, Supabase is required.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Add to Home screen" not showing | Make sure you're on HTTPS (Vercel always is). Try loading the page, waiting 30s, then check the menu again. |
| App opens in browser instead of full-screen | Uninstall the home screen shortcut and re-add it after the latest deploy. |
| "No dog found" error when joining | Double-check the ID — it's case-sensitive and must match exactly (e.g. `LUNA-4829`) |
| Data not syncing | Check Supabase → Table Editor → `sessions` to confirm rows are being written. Check Vercel environment variables are set correctly. |
| Blank screen on load | Open Chrome DevTools → Console and look for errors. Most likely a missing env variable. |

---

## Folder structure summary

```
pawtimer/                   ← repo root
├── index.html              ← PWA meta tags, theme colour, manifest link
├── manifest.json           ← PWA manifest (icons, display: standalone)
├── package.json            ← dependencies
├── vite.config.js          ← Vite + PWA plugin config
├── .env.example            ← template (do NOT fill in real values here)
├── supabase_setup.sql      ← run once in Supabase SQL editor
├── icons/
│   ├── icon-192.png        ← home screen icon (amber paw print)
│   ├── icon-512.png        ← splash screen icon
│   └── icon-maskable.png   ← Android adaptive icon (fills the shape)
└── src/
    ├── main.jsx            ← React entry point
    └── App.jsx             ← full app
```
